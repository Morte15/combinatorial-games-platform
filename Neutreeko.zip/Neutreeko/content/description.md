(`)Zasady gry:
Czarne pionki zawsze poruszają się jako pierwsze.
Pionki przesuwają się prostopadle lub ukośnie, aż zostaną zablokowane przez krawędź planszy (5x5) lub inny element (czyli pionek gracza lub przeciwnika).
Celem gry jest ułożenie pionków w rzędzie, prostopadle lub na ukos.(`)